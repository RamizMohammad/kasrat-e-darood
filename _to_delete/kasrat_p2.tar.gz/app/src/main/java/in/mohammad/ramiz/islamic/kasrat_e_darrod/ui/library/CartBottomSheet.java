package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.library;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;
import com.google.android.material.progressindicator.IndeterminateDrawable;

import java.util.List;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.core.Haptics;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.Cart;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.LogService;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.CountRollTextView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.TickView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Numbers;

/**
 * P2 · Cart review (screen 13). Steppers edit the cart live; "Log all" sends
 * everything in one request. The server saves the whole batch or nothing, so
 * on failure the cart is kept as it was and "Try again" re-sends the same
 * client_uuids (nothing can count twice). Success: sage tick, then it closes.
 */
public class CartBottomSheet extends BottomSheetDialogFragment implements Cart.Listener {

    private CartLineAdapter adapter;
    private TextView summary, empty, error;
    private CountRollTextView total;
    private MaterialButton logAll;
    private View lines, totalRow, done;
    private boolean sending, finished;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.sheet_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        summary = view.findViewById(R.id.cart_summary);
        empty = view.findViewById(R.id.cart_empty);
        error = view.findViewById(R.id.cart_error);
        total = view.findViewById(R.id.cart_total);
        logAll = view.findViewById(R.id.cart_log);
        lines = view.findViewById(R.id.cart_lines);
        totalRow = view.findViewById(R.id.cart_total_row);
        done = view.findViewById(R.id.cart_done);

        RecyclerView rv = (RecyclerView) lines;
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new CartLineAdapter();
        rv.setAdapter(adapter);
        logAll.setOnClickListener(v -> send());
        render(false);
    }

    @Override
    public void onStart() {
        super.onStart();
        Cart.get().addListener(this);
    }

    @Override
    public void onStop() {
        Cart.get().removeListener(this);
        super.onStop();
    }

    @Override
    public void onCartChanged() {
        if (!finished && getView() != null) render(true);
    }

    private void render(boolean animate) {
        Cart cart = Cart.get();
        adapter.setLines(cart.lines());
        int n = cart.distinctCount();
        summary.setText(getResources().getQuantityString(R.plurals.cart_items, n, n).toUpperCase(java.util.Locale.getDefault()));
        total.setCount(cart.totalCount(), animate && total.hasCount());
        boolean isEmpty = cart.isEmpty();
        empty.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        totalRow.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        logAll.setEnabled(!isEmpty && !sending);
        if (isEmpty) error.setVisibility(View.GONE);
    }

    private void send() {
        List<Cart.Line> batch = Cart.get().lines();
        if (batch.isEmpty() || sending) return;
        sending = true;
        error.setVisibility(View.GONE);
        logAll.setEnabled(false);
        logAll.setText(R.string.cart_logging);
        logAll.setIcon(spinner());
        LogService.logCart(requireContext(), batch, new LogService.Result() {
            @Override
            public void onLogged(@NonNull dto.Totals totals) {
                sending = false;
                long count = 0;
                for (Cart.Line l : batch) count += l.count;
                Cart.get().removeLogged(batch);
                if (!isAdded()) return;
                showDone(count);
            }

            @Override
            public void onFailed(@NonNull String message, boolean offline) {
                sending = false;
                if (!isAdded()) return;
                Haptics.reject(requireContext());
                logAll.setIcon(null);
                logAll.setText(R.string.action_try_again);
                logAll.setEnabled(!Cart.get().isEmpty());
                error.setText(getString(R.string.cart_failed, message));
                error.setVisibility(View.VISIBLE);
            }
        });
    }

    private void showDone(long count) {
        finished = true;
        Haptics.click(requireContext());
        lines.setVisibility(View.GONE);
        totalRow.setVisibility(View.GONE);
        empty.setVisibility(View.GONE);
        error.setVisibility(View.GONE);
        logAll.setVisibility(View.GONE);
        summary.setVisibility(View.INVISIBLE);
        done.setVisibility(View.VISIBLE);
        ((TextView) done.findViewById(R.id.cart_done_text)).setText(
                getString(R.string.cart_logged, Numbers.format(count)));
        TickView tick = done.findViewById(R.id.cart_tick);
        tick.play();
        done.postDelayed(() -> {
            if (isAdded()) dismissAllowingStateLoss();
        }, 1200);
    }

    @NonNull
    private IndeterminateDrawable<CircularProgressIndicatorSpec> spinner() {
        CircularProgressIndicatorSpec spec = new CircularProgressIndicatorSpec(requireContext(), null, 0,
                R.style.Widget_Kasrat_Progress_Circular);
        spec.indicatorSize = (int) (18 * getResources().getDisplayMetrics().density);
        spec.trackThickness = (int) (2 * getResources().getDisplayMetrics().density);
        spec.indicatorColors = new int[]{androidx.core.content.ContextCompat.getColor(requireContext(), R.color.paper_ink)};
        return IndeterminateDrawable.createCircularDrawable(requireContext(), spec);
    }
}
