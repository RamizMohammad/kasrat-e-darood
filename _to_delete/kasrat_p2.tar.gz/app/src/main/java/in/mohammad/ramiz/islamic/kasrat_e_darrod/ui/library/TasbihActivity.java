package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.library;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.List;
import java.util.UUID;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.core.Haptics;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.LogService;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.RecitationStore;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.base.BaseActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.CountRollTextView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.CounterRingView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.TickView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.EdgeInsets;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Numbers;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.AppPrefs;

/**
 * P2 · Tasbih counter (screen 12).
 *
 * Every tap is saved straight away (per recitation), so the count survives the
 * phone locking, rotation and the app being closed. "Log N" sends the count
 * with a client_uuid; pressing "Try again" without counting more re-sends the
 * same one, so a retry after a dropped connection can't log it twice. The
 * screen stays on while open.
 */
public class TasbihActivity extends BaseActivity {

    private static final String EXTRA_ID = "recitation_id";
    private static final String PREFS = "kasrat_tasbih";
    private static final int MAX_TARGET = 99_999;

    @NonNull
    public static Intent intent(@NonNull Context ctx, @NonNull String recitationId) {
        return new Intent(ctx, TasbihActivity.class).putExtra(EXTRA_ID, recitationId);
    }

    private String id;
    private SharedPreferences prefs;
    private CounterRingView ring;
    private CountRollTextView countText;
    private TextView of, error;
    private View tapArea, done;
    private MaterialButton log, undo;
    private ChipGroup targets;
    private int count, target;
    private String uuid;
    private boolean sending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasbih);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        EdgeInsets.padSystemBars(findViewById(R.id.root), false);
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        id = getIntent().getStringExtra(EXTRA_ID);
        if (id == null) {
            finish();
            return;
        }
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        count = prefs.getInt(id + ":count", 0);
        target = prefs.getInt(id + ":target", 33);
        uuid = prefs.getString(id + ":uuid", null);
        if (uuid == null) newUuid();

        ring = findViewById(R.id.tasbih_ring);
        countText = findViewById(R.id.tasbih_count);
        of = findViewById(R.id.tasbih_of);
        error = findViewById(R.id.tasbih_error);
        done = findViewById(R.id.tasbih_done);
        tapArea = findViewById(R.id.tasbih_tap);
        log = findViewById(R.id.tasbih_log);
        undo = findViewById(R.id.tasbih_undo);
        targets = findViewById(R.id.tasbih_targets);

        bindRecitation();
        tapArea.setOnClickListener(v -> tap());
        undo.setOnClickListener(v -> undo());
        log.setOnClickListener(v -> send());
        bindTargetChips();
        ring.setTarget(target);
        render(false);
    }

    private void bindRecitation() {
        String lang = new AppPrefs(this).lang();
        RecitationStore store = RecitationStore.get(this);
        dto.RecitationDto r = store.byId(id);
        if (r != null) {
            show(r, lang);
            return;
        }
        store.load(new RecitationStore.Callback() {
            @Override public void onList(@NonNull List<dto.RecitationDto> list, boolean fromCache) {
                dto.RecitationDto found = store.byId(id);
                if (found != null && !isFinishing()) show(found, lang);
            }

            @Override public void onError(boolean offline) { }
        });
    }

    private void show(@NonNull dto.RecitationDto r, @NonNull String lang) {
        ((TextView) findViewById(R.id.tasbih_name)).setText(RecitationStore.title(r, lang));
        ((TextView) findViewById(R.id.tasbih_arabic)).setText(r.arabicName);
    }

    // ── Counting ────────────────────────────────────────────────────────────

    private void tap() {
        if (sending) return;
        count++;
        newUuid();          // a different count is a different log
        save();
        done.setVisibility(View.GONE);
        error.setVisibility(View.GONE);
        boolean atTarget = ring.isAtTarget(count);
        tapArea.performHapticFeedback(atTarget
                ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.CLOCK_TICK);
        render(true);
    }

    private void undo() {
        if (count <= 0 || sending) return;
        count--;
        newUuid();
        save();
        Haptics.tick(this);
        render(true);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Volume keys count too, so you can keep the phone in your pocket.
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.getRepeatCount() == 0) tap();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void render(boolean animate) {
        ring.setCount(count, animate);
        countText.setCount(count, animate && countText.hasCount());
        int rounds = count / target;
        of.setText(rounds > 0
                ? getString(R.string.tasbih_of_rounds, Numbers.format(target), rounds)
                : getString(R.string.tasbih_of, Numbers.format(target)));
        tapArea.setContentDescription(getString(R.string.tasbih_tap_cd, count, target));
        undo.setEnabled(count > 0 && !sending);
        log.setEnabled(count > 0 && !sending);
        if (!sending) log.setText(count > 0
                ? getString(R.string.tasbih_log, Numbers.format(count))
                : getString(R.string.tasbih_log_empty));
    }

    private void save() {
        prefs.edit().putInt(id + ":count", count).putInt(id + ":target", target)
                .putString(id + ":uuid", uuid).apply();
    }

    private void newUuid() {
        uuid = UUID.randomUUID().toString();
    }

    // ── Target ──────────────────────────────────────────────────────────────

    private void bindTargetChips() {
        int checked = target == 33 ? R.id.target_33 : target == 100 ? R.id.target_100 : R.id.target_custom;
        targets.check(checked);
        if (checked == R.id.target_custom) {
            ((TextView) findViewById(R.id.target_custom)).setText(Numbers.format(target));
        }
        targets.setOnCheckedStateChangeListener((group, ids) -> {
            if (ids.isEmpty()) return;
            int pick = ids.get(0);
            if (pick == R.id.target_33) setTarget(33);
            else if (pick == R.id.target_100) setTarget(100);
        });
        // Custom opens a number dialog every tap, even when already selected.
        findViewById(R.id.target_custom).setOnClickListener(v -> askCustom());
    }

    private void setTarget(int t) {
        target = Math.max(1, Math.min(MAX_TARGET, t));
        ((TextView) findViewById(R.id.target_custom)).setText(
                target == 33 || target == 100 ? getString(R.string.tasbih_custom) : Numbers.format(target));
        ring.setTarget(target);
        save();
        render(false);
    }

    private void askCustom() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_number, null, false);
        TextInputLayout layout = v.findViewById(R.id.number_layout);
        TextInputEditText input = v.findViewById(R.id.number_input);
        if (target != 33 && target != 100) input.setText(String.valueOf(target));
        androidx.appcompat.app.AlertDialog d = new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.tasbih_custom_title)
                .setView(v)
                .setPositiveButton(R.string.action_save, null)
                .setNegativeButton(R.string.action_cancel, null)
                .create();
        d.setOnShowListener(x -> d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(b -> {
            int n;
            try {
                n = Integer.parseInt(String.valueOf(input.getText()).trim());
            } catch (NumberFormatException e) {
                n = 0;
            }
            if (n < 1 || n > MAX_TARGET) {
                layout.setError(getString(R.string.tasbih_custom_error, Numbers.format(MAX_TARGET)));
                return;
            }
            setTarget(n);
            targets.check(R.id.target_custom);
            d.dismiss();
        }));
        d.setOnDismissListener(x -> {
            // Cancelled without a custom target: put the chip back on the current one.
            int current = target == 33 ? R.id.target_33 : target == 100 ? R.id.target_100 : R.id.target_custom;
            if (targets.getCheckedChipId() != current) targets.check(current);
        });
        d.show();
    }

    // ── Logging ─────────────────────────────────────────────────────────────

    private void send() {
        if (count <= 0 || sending) return;
        sending = true;
        int sent = count;
        log.setText(R.string.cart_logging);
        render(false);
        LogService.logOne(this, id, sent, uuid, new LogService.Result() {
            @Override
            public void onLogged(@NonNull dto.Totals totals) {
                sending = false;
                count = 0;                                // taps are blocked while sending
                newUuid();
                save();
                if (isFinishing()) return;
                Haptics.click(TasbihActivity.this);
                done.setVisibility(View.VISIBLE);
                ((TextView) findViewById(R.id.tasbih_done_text)).setText(
                        getString(R.string.tasbih_logged, Numbers.format(sent)));
                ((TickView) findViewById(R.id.tasbih_tick)).play();
                render(true);
            }

            @Override
            public void onFailed(@NonNull String message, boolean offline) {
                sending = false;
                if (isFinishing()) return;
                Haptics.reject(TasbihActivity.this);
                error.setText(getString(R.string.tasbih_failed, message));
                error.setVisibility(View.VISIBLE);
                render(false);
            }
        });
    }
}
