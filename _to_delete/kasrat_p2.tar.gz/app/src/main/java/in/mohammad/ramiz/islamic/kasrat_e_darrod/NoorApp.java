package in.mohammad.ramiz.islamic.kasrat_e_darrod;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.fcm.NoorMessagingService;

/** Applies persisted UI settings and sets up push notifications at process start. */
public class NoorApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // v3 is dark-only (Confess "Midnight Letters"): force night mode so any
        // DayNight library UI matches. The per-app locale is restored by AppCompat.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        // Push notifications: create the channel and subscribe to the broadcast topic.
        NoorMessagingService.ensureChannel(this);
        NoorMessagingService.subscribeToCommunity();
        // Restore the recitation cart saved before the app was last closed.
        in.mohammad.ramiz.islamic.kasrat_e_darrod.data.Cart.get().attach(this);
    }
}
