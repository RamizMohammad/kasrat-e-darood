package in.mohammad.ramiz.islamic.kasrat_e_darrod;

import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.core.Haptics;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.databinding.ActivityMainBinding;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.base.BaseActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.home.HomeFragment;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.library.LibraryFragment;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.profile.ProfileFragment;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.shell.GroupsSoonFragment;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.shell.RanksFragment;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.EdgeInsets;

/**
 * v3 shell: Home · Recite · Groups · Ranks · Me on the Confess-style bottom bar.
 * Home and Recite are the P2 screens; Me still hosts the v2 profile until P3;
 * Groups shows "coming soon" until P5; Ranks hosts v2's board + stats until P4.
 */
public class MainActivity extends BaseActivity {

    private static final String STATE_TAB = "tab";
    private static final int HOME = 0, RECITE = 1, GROUPS = 2, RANKS = 3, ME = 4;
    public static final int TAB_HOME = HOME, TAB_RECITE = RECITE, TAB_GROUPS = GROUPS,
            TAB_RANKS = RANKS, TAB_ME = ME;

    private ActivityMainBinding b;
    private View[] tabs;
    private ImageView[] icons;
    private TextView[] labels;
    private int current = -1;

    private final ActivityResultLauncher<String> notifPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        b = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        EdgeInsets.padTop(b.navHost);
        EdgeInsets.padBottom(b.bottomBar.getRoot(), false);

        // Android 13+: pushes need permission. (P8 adds an explainer screen first.)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS);
        }

        tabs = new View[]{b.bottomBar.tabHome, b.bottomBar.tabRecite, b.bottomBar.tabGroups,
                b.bottomBar.tabRanks, b.bottomBar.tabMe};
        icons = new ImageView[]{b.bottomBar.iconHome, b.bottomBar.iconRecite, b.bottomBar.iconGroups,
                b.bottomBar.iconRanks, b.bottomBar.iconMe};
        labels = new TextView[]{b.bottomBar.labelHome, b.bottomBar.labelRecite, b.bottomBar.labelGroups,
                b.bottomBar.labelRanks, b.bottomBar.labelMe};
        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            tabs[i].setOnClickListener(v -> {
                if (index != current) Haptics.tick(this);
                select(index, true);
            });
        }

        int start = savedInstanceState != null ? savedInstanceState.getInt(STATE_TAB, HOME) : HOME;
        select(start, savedInstanceState == null);
    }

    private void select(int index, boolean replaceFragment) {
        boolean changed = index != current;
        current = index;
        int on = ContextCompat.getColor(this, R.color.amber);
        int off = ContextCompat.getColor(this, R.color.text_secondary);
        for (int i = 0; i < tabs.length; i++) {
            boolean selected = i == index;
            icons[i].setImageTintList(ColorStateList.valueOf(selected ? on : off));
            labels[i].setTextColor(selected ? on : off);
            tabs[i].setSelected(selected);
        }
        if (changed && replaceFragment) show(fragmentFor(index));
    }

    /** Switch tabs from inside a screen (Home's group card → Ranks, avatar → Me). */
    public void openTab(int index) {
        if (index != current) Haptics.tick(this);
        select(index, true);
    }

    @NonNull
    private static Fragment fragmentFor(int index) {
        switch (index) {
            case RECITE: return new LibraryFragment();
            case GROUPS: return new GroupsSoonFragment();
            case RANKS: return new RanksFragment();
            case ME: return new ProfileFragment();
            default: return new HomeFragment();
        }
    }

    private void show(@NonNull Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.anim.tab_in, R.anim.tab_out)
                .replace(R.id.nav_host, fragment)
                .commit();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt(STATE_TAB, current);
    }
}
