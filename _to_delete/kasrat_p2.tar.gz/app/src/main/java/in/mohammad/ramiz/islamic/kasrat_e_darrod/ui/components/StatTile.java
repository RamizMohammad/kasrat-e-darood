package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;

/**
 * A number over a small caps label (Today · Week · Lifetime · Streak), on a
 * raised plate. The number rolls when it changes.
 *
 *   <…StatTile app:statLabel="@string/stat_today" />
 */
public class StatTile extends LinearLayout {

    private final CountRollTextView value;
    private final TextView label;

    public StatTile(@NonNull Context context) {
        this(context, null);
    }

    public StatTile(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setOrientation(VERTICAL);
        setBackgroundResource(R.drawable.bg_plate);
        int pad = getResources().getDimensionPixelSize(R.dimen.space_12);
        setPadding(pad, pad, pad, pad);
        LayoutInflater.from(context).inflate(R.layout.view_stat_tile, this, true);
        value = findViewById(R.id.stat_value);
        label = findViewById(R.id.stat_label);
        value.clearCount();
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.StatTile);
            CharSequence l = a.getText(R.styleable.StatTile_statLabel);
            if (l != null) label.setText(l);
            a.recycle();
        }
    }

    public void setValue(long n, boolean animate) {
        value.setCount(n, animate);
        setContentDescription(label.getText() + ": " + value.getText());
    }

    public void clear() { value.clearCount(); }

    public boolean hasValue() { return value.hasCount(); }

    public void setLabel(@NonNull CharSequence text) { label.setText(text); }
}
