package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.library;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.Cart;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.RecitationStore;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.ApiClient;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.notifications.NotificationsActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Motion;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Numbers;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.SimpleTextWatcher;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.AppPrefs;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.Skeleton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * P2 · Library (screen 10). Shows the saved list at once, then the server's.
 * Category chips and search filter on the phone. Card chips and steppers fill
 * the cart; the floating bar opens the review sheet.
 */
public class LibraryFragment extends Fragment implements Cart.Listener, RecitationStore.Callback {

    /** Roles allowed to add recitations (server: _LIBRARY_MANAGER_ROLES). */
    private static final Set<String> MANAGERS = Set.of("super_member", "super_admin");
    private static Boolean canManage;   // cached for the session once /auth/me answers

    private RecyclerView list;
    private RecitationCardAdapter adapter;
    private SwipeRefreshLayout refresh;
    private ChipGroup chips;
    private EditText search;
    private View cartBar, skeleton, state, offline;
    private TextView cartBarText;
    private List<dto.RecitationDto> all = new ArrayList<>();
    @Nullable private String category;      // null = All
    private boolean firstFill = true;

    private final ActivityResultLauncher<Intent> addRecitation = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), r -> {
                if (r.getResultCode() == android.app.Activity.RESULT_OK && isAdded()) {
                    RecitationStore.get(requireContext()).refresh(this);
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_library, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        String lang = new AppPrefs(requireContext()).lang();
        view.findViewById(R.id.library_bell).setOnClickListener(v ->
                startActivity(new Intent(requireContext(), NotificationsActivity.class)));
        MaterialButton add = view.findViewById(R.id.library_add);
        add.setOnClickListener(v -> addRecitation.launch(new Intent(requireContext(), AddRecitationActivity.class)));

        list = view.findViewById(R.id.library_list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new RecitationCardAdapter(lang, r ->
                startActivity(RecitationDetailActivity.intent(requireContext(), r.id)));
        list.setAdapter(adapter);
        refresh = view.findViewById(R.id.library_refresh);
        refresh.setColorSchemeColors(ContextCompat.getColor(requireContext(), R.color.amber));
        refresh.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(requireContext(), R.color.surface_raised));
        refresh.setOnRefreshListener(() -> RecitationStore.get(requireContext()).refresh(this));

        chips = view.findViewById(R.id.library_chips);
        search = view.findViewById(R.id.library_search);
        search.addTextChangedListener(new SimpleTextWatcher(text -> apply()));
        skeleton = view.findViewById(R.id.library_skeleton);
        state = view.findViewById(R.id.library_state);
        offline = view.findViewById(R.id.library_offline);
        cartBar = view.findViewById(R.id.cart_bar);
        cartBarText = view.findViewById(R.id.cart_bar_text);
        cartBar.setOnClickListener(v -> openCart());

        if (savedInstanceState != null) category = savedInstanceState.getString("category");
        skeleton.setVisibility(View.VISIBLE);
        Skeleton.shimmer(skeleton);
        RecitationStore.get(requireContext()).load(this);
        checkRole(add);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("category", category);
    }

    @Override
    public void onStart() {
        super.onStart();
        Cart.get().addListener(this);
        onCartChanged();
    }

    @Override
    public void onStop() {
        Cart.get().removeListener(this);
        super.onStop();
    }

    @Override
    public void onCartChanged() {
        if (adapter != null) adapter.cartChanged();
        updateCartBar();
    }

    // ── Data ────────────────────────────────────────────────────────────────

    @Override
    public void onList(@NonNull List<dto.RecitationDto> list, boolean fromCache) {
        if (!isAdded()) return;
        if (!fromCache) {
            refresh.setRefreshing(false);
            offline.setVisibility(View.GONE);
        }
        all = new ArrayList<>(list);
        Skeleton.reveal(skeleton, null);
        buildChips();
        apply();
    }

    @Override
    public void onError(boolean isOffline) {
        if (!isAdded()) return;
        refresh.setRefreshing(false);
        Skeleton.reveal(skeleton, null);
        if (!all.isEmpty()) {
            offline.setVisibility(View.VISIBLE);       // keep showing the saved list
            return;
        }
        showState(isOffline ? R.string.recite_offline_title : R.string.recite_error_title,
                R.string.recite_error_hint, R.string.action_try_again, true, v -> {
                    state.setVisibility(View.GONE);
                    skeleton.setVisibility(View.VISIBLE);
                    Skeleton.shimmer(skeleton);
                    RecitationStore.get(requireContext()).refresh(this);
                });
    }

    private void checkRole(@NonNull MaterialButton add) {
        if (canManage != null) {
            add.setVisibility(canManage ? View.VISIBLE : View.GONE);
            return;
        }
        ApiClient.get(requireContext()).me().enqueue(new Callback<dto.UserDto>() {
            @Override
            public void onResponse(@NonNull Call<dto.UserDto> call, @NonNull Response<dto.UserDto> r) {
                if (r.isSuccessful() && r.body() != null) canManage = MANAGERS.contains(r.body().role);
                if (isAdded() && canManage != null) add.setVisibility(canManage ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onFailure(@NonNull Call<dto.UserDto> call, @NonNull Throwable t) { }
        });
    }

    // ── Filtering ───────────────────────────────────────────────────────────

    private void buildChips() {
        Set<String> cats = new LinkedHashSet<>();
        for (dto.RecitationDto r : all) if (r.category != null && !r.category.isEmpty()) cats.add(r.category);
        if (category != null && !cats.contains(category)) category = null;
        chips.setOnCheckedStateChangeListener(null);
        chips.removeAllViews();
        chips.addView(chip(getString(R.string.recite_all), null));
        for (String c : cats) chips.addView(chip(c, c));
        chips.setOnCheckedStateChangeListener((group, ids) -> {
            if (ids.isEmpty()) return;
            Chip picked = group.findViewById(ids.get(0));
            category = picked != null ? (String) picked.getTag() : null;
            apply();
            list.scrollToPosition(0);
        });
    }

    @NonNull
    private Chip chip(@NonNull String label, @Nullable String value) {
        Chip c = (Chip) LayoutInflater.from(requireContext()).inflate(R.layout.item_filter_chip, chips, false);
        c.setId(View.generateViewId());
        c.setText(label);
        c.setTag(value);
        c.setChecked(value == null ? category == null : value.equals(category));
        return c;
    }

    private void apply() {
        if (adapter == null) return;
        String q = search.getText() != null ? search.getText().toString().trim().toLowerCase(Locale.ROOT) : "";
        List<dto.RecitationDto> shown = new ArrayList<>();
        for (dto.RecitationDto r : all) {
            if (category != null && !category.equals(r.category)) continue;
            if (!q.isEmpty() && !matches(r, q)) continue;
            shown.add(r);
        }
        adapter.submitList(shown, () -> {
            if (firstFill && !shown.isEmpty()) {
                firstFill = false;
                Motion.enterList(list);
            }
        });
        if (all.isEmpty()) return;
        if (shown.isEmpty()) {
            showState(R.string.recite_no_results, R.string.recite_no_results_hint,
                    R.string.recite_clear_filters, false, v -> {
                        search.setText("");
                        category = null;
                        buildChips();
                        apply();
                    });
        } else {
            state.setVisibility(View.GONE);
        }
    }

    private static boolean matches(@NonNull dto.RecitationDto r, @NonNull String q) {
        return has(r.englishName, q) || has(r.urduName, q) || has(r.arabicName, q)
                || has(r.transliteration, q) || has(r.translation, q) || has(r.category, q);
    }

    private static boolean has(@Nullable String field, @NonNull String q) {
        return field != null && field.toLowerCase(Locale.ROOT).contains(q);
    }

    private void showState(int title, int hint, int action, boolean error, View.OnClickListener onAction) {
        state.setVisibility(View.VISIBLE);
        state.setBackgroundResource(error ? R.drawable.bg_error_plate : 0);
        ((TextView) state.findViewById(R.id.library_state_title)).setText(title);
        ((TextView) state.findViewById(R.id.library_state_hint)).setText(hint);
        MaterialButton b = state.findViewById(R.id.library_state_action);
        b.setText(action);
        b.setOnClickListener(onAction);
    }

    // ── Cart ────────────────────────────────────────────────────────────────

    private void openCart() {
        if (Cart.get().isEmpty()) return;
        if (getChildFragmentManager().findFragmentByTag("cart") != null) return;
        new CartBottomSheet().show(getChildFragmentManager(), "cart");
    }

    private void updateCartBar() {
        if (cartBar == null) return;
        Cart cart = Cart.get();
        boolean show = !cart.isEmpty();
        if (show) {
            int n = cart.distinctCount();
            cartBarText.setText(getString(R.string.cart_bar,
                    getResources().getQuantityString(R.plurals.cart_items, n, n),
                    Numbers.format(cart.totalCount())));
        }
        if (show == (cartBar.getVisibility() == View.VISIBLE)) return;
        if (!Motion.enabled()) {
            cartBar.setVisibility(show ? View.VISIBLE : View.GONE);
            return;
        }
        float dy = 24 * getResources().getDisplayMetrics().density;
        if (show) {
            cartBar.setAlpha(0f);
            cartBar.setTranslationY(dy);
            cartBar.setVisibility(View.VISIBLE);
            cartBar.animate().alpha(1f).translationY(0f).setDuration(220).withEndAction(null).start();
        } else {
            cartBar.animate().alpha(0f).translationY(dy).setDuration(180)
                    .withEndAction(() -> cartBar.setVisibility(View.GONE)).start();
        }
    }
}
