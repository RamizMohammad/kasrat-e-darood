package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.library;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.core.Haptics;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.Cart;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.RecitationStore;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.ApiClient;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.base.BaseActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.StatTile;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.EdgeInsets;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Motion;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Numbers;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.AppPrefs;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * P2 · Recitation detail (screen 11): the full text, your recent total for it,
 * "Count with tasbih" and add-to-cart.
 *
 * "Your recent total" adds up this recitation in your last 100 logs; the exact
 * all-time figure arrives with /statistics/me in B1.
 */
public class RecitationDetailActivity extends BaseActivity implements Cart.Listener {

    private static final String EXTRA_ID = "recitation_id";

    @NonNull
    public static Intent intent(@NonNull Context ctx, @NonNull String recitationId) {
        return new Intent(ctx, RecitationDetailActivity.class).putExtra(EXTRA_ID, recitationId);
    }

    private dto.RecitationDto rec;
    private String lang;
    private StatTile inCart;
    private MaterialButton add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recitation_detail);
        EdgeInsets.padTop(findViewById(R.id.root));
        EdgeInsets.padBottom(findViewById(R.id.detail_actions), false);
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        lang = new AppPrefs(this).lang();
        inCart = findViewById(R.id.detail_in_cart);
        add = findViewById(R.id.detail_add);

        String id = getIntent().getStringExtra(EXTRA_ID);
        RecitationStore store = RecitationStore.get(this);
        dto.RecitationDto r = store.byId(id);
        if (r != null) {
            bind(r, savedInstanceState == null);
        } else {
            store.load(new RecitationStore.Callback() {
                @Override public void onList(@NonNull List<dto.RecitationDto> list, boolean fromCache) {
                    dto.RecitationDto found = store.byId(id);
                    if (found != null && rec == null && !isFinishing()) bind(found, true);
                }

                @Override public void onError(boolean offline) {
                    if (rec == null && !isFinishing()) {
                        Toast.makeText(RecitationDetailActivity.this, R.string.error_network, Toast.LENGTH_LONG).show();
                        finish();
                    }
                }
            });
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Cart.get().addListener(this);
        onCartChanged();
    }

    @Override
    protected void onStop() {
        Cart.get().removeListener(this);
        super.onStop();
    }

    @Override
    public void onCartChanged() {
        if (rec == null) return;
        inCart.setValue(Cart.get().countFor(rec.id), inCart.hasValue());
    }

    private void bind(@NonNull dto.RecitationDto r, boolean animate) {
        rec = r;
        String title = RecitationStore.title(r, lang);
        text(R.id.detail_category, r.category != null ? r.category.toUpperCase(Locale.getDefault()) : null);
        text(R.id.detail_arabic, r.arabicName);
        text(R.id.detail_transliteration, r.transliteration);
        text(R.id.detail_name, title);
        text(R.id.detail_meaning, r.translation);
        text(R.id.detail_reference, r.reference);

        int step = RecitationStore.step(r);
        add.setText(getString(R.string.detail_add_to_cart, Numbers.format(step)));
        add.setOnClickListener(v -> {
            Haptics.tick(this);
            Cart.get().add(r.id, r.arabicName, title, step);
        });
        findViewById(R.id.detail_tasbih).setOnClickListener(v ->
                startActivity(TasbihActivity.intent(this, r.id)));
        onCartChanged();
        loadYours(r.id);
        if (animate) Motion.enterStack(findViewById(R.id.detail_column));
    }

    private void loadYours(@NonNull String id) {
        StatTile yours = findViewById(R.id.detail_yours);
        ApiClient.get(this).recentSubmissions(100).enqueue(new Callback<List<dto.MySubmissionDto>>() {
            @Override
            public void onResponse(@NonNull Call<List<dto.MySubmissionDto>> call,
                                   @NonNull Response<List<dto.MySubmissionDto>> r) {
                if (isFinishing() || !r.isSuccessful() || r.body() == null) return;
                long sum = 0;
                for (dto.MySubmissionDto s : r.body()) if (id.equals(s.recitationId)) sum += s.count;
                yours.setValue(sum, false);
            }

            @Override
            public void onFailure(@NonNull Call<List<dto.MySubmissionDto>> call, @NonNull Throwable t) { }
        });
    }

    private void text(int viewId, @Nullable String value) {
        TextView tv = findViewById(viewId);
        tv.setText(value);
        tv.setVisibility(TextUtils.isEmpty(value) ? View.GONE : View.VISIBLE);
    }
}
