package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Motion;

/**
 * Tasbih ring: an amber arc that fills a little with every tap toward a target
 * (33, 100 or custom), starting at the top. Each completed round of the target
 * shows as a full gold ring for a moment, then the next round starts from empty.
 * It fills clockwise, or counter-clockwise in right-to-left languages.
 *
 * The count itself is drawn by a separate CountRollTextView laid over the centre.
 */
public class CounterRingView extends View {

    private static final long STEP_MS = 90;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final int amber, gold;

    private int target = 33;
    private int count;
    private float shown;            // 0..1 of the current round, animated
    @Nullable private ValueAnimator anim;

    public CounterRingView(@NonNull Context context) {
        this(context, null);
    }

    public CounterRingView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        float stroke = getResources().getDisplayMetrics().density * 10;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(ContextCompat.getColor(context, R.color.surface_high));
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(stroke);
        arc.setStrokeCap(Paint.Cap.ROUND);
        amber = ContextCompat.getColor(context, R.color.amber);
        gold = ContextCompat.getColor(context, R.color.story_gold);
        dot.setColor(amber);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    public void setTarget(int target) {
        this.target = Math.max(1, target);
        jumpTo(fraction(count));
    }

    public int getTarget() { return target; }

    /** True when {@code n} is a whole number of rounds (and not zero). */
    public boolean isAtTarget(int n) { return n > 0 && n % target == 0; }

    public void setCount(int n, boolean animate) {
        count = Math.max(0, n);
        float to = fraction(count);
        if (!animate || !Motion.enabled() || !isLaidOut()) {
            jumpTo(to);
            return;
        }
        if (anim != null) anim.cancel();
        float startAt = to < shown ? 0f : shown;   // a new round starts from empty
        anim = ValueAnimator.ofFloat(startAt, to);
        anim.setDuration(STEP_MS);
        anim.setInterpolator(new FastOutSlowInInterpolator());
        anim.addUpdateListener(a -> {
            shown = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    private float fraction(int n) {
        if (n <= 0) return 0f;
        int inRound = n % target;
        return inRound == 0 ? 1f : inRound / (float) target;
    }

    private void jumpTo(float f) {
        if (anim != null) anim.cancel();
        shown = f;
        invalidate();
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        float half = track.getStrokeWidth() / 2f;
        float size = Math.min(getWidth() - getPaddingLeft() - getPaddingRight(),
                getHeight() - getPaddingTop() - getPaddingBottom());
        float left = getPaddingLeft() + (getWidth() - getPaddingLeft() - getPaddingRight() - size) / 2f;
        float top = getPaddingTop() + (getHeight() - getPaddingTop() - getPaddingBottom() - size) / 2f;
        box.set(left + half, top + half, left + size - half, top + size - half);
        canvas.drawOval(box, track);
        if (shown <= 0f) return;

        boolean rtl = getLayoutDirection() == LAYOUT_DIRECTION_RTL;
        boolean full = shown >= 1f;
        arc.setColor(full ? gold : amber);
        float sweep = 360f * Math.min(1f, shown) * (rtl ? -1f : 1f);
        canvas.drawArc(box, -90f, sweep, false, arc);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }
}
