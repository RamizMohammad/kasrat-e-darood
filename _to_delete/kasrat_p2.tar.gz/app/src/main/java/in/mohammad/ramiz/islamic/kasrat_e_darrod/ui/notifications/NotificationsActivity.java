package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.ApiClient;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.base.BaseActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.SegmentedToggle;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.EdgeInsets;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Motion;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.RelativeTime;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.Skeleton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * P2 · Notifications (screen 9). Three tabs:
 *   Activity — community logs ("activity")
 *   Groups   — join approvals, goals, rank changes (arrives with groups in P7)
 *   System   — reminders and quotes ("notifications") + closed weeks ("considerations")
 */
public class NotificationsActivity extends BaseActivity {

    private static final int ACTIVITY = 0, GROUPS = 1, SYSTEM = 2;

    private RecyclerView list;
    private SwipeRefreshLayout refresh;
    private View skeleton, state;
    private int tab = ACTIVITY;
    private int request;            // ignores replies for a tab you've already left

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        View root = findViewById(R.id.root);
        EdgeInsets.padTop(root);
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        list = findViewById(R.id.notif_list);
        list.setLayoutManager(new LinearLayoutManager(this));
        EdgeInsets.padBottom(list, false);
        refresh = findViewById(R.id.notif_refresh);
        refresh.setColorSchemeColors(ContextCompat.getColor(this, R.color.amber));
        refresh.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(this, R.color.surface_raised));
        refresh.setOnRefreshListener(() -> load(false));
        skeleton = findViewById(R.id.notif_skeleton);
        state = findViewById(R.id.notif_state);
        findViewById(R.id.notif_state_action).setOnClickListener(v -> load(true));

        SegmentedToggle tabs = findViewById(R.id.notif_tabs);
        int[] ids = {R.id.tab_activity, R.id.tab_groups, R.id.tab_system};
        if (savedInstanceState != null) tab = savedInstanceState.getInt("tab", ACTIVITY);
        tabs.check(ids[tab]);
        tabs.addOnButtonCheckedListener((group, id, checked) -> {
            if (!checked) return;
            for (int i = 0; i < ids.length; i++) if (ids[i] == id) tab = i;
            load(true);
        });
        load(true);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", tab);
    }

    private void load(boolean showSkeleton) {
        int mine = ++request;
        state.setVisibility(View.GONE);
        if (tab == GROUPS) {
            refresh.setRefreshing(false);
            show(mine, Collections.emptyList(), false);
            return;
        }
        if (showSkeleton) {
            list.setAdapter(null);
            skeleton.setVisibility(View.VISIBLE);
            Skeleton.shimmer(skeleton);
        }
        List<String> categories = tab == ACTIVITY
                ? Collections.singletonList("activity")
                : java.util.Arrays.asList("notifications", "considerations");
        List<dto.ActivityDto> merged = new ArrayList<>();
        int[] left = {categories.size()};
        boolean[] failed = {false};
        for (String c : categories) {
            ApiClient.get(this).notifications(c).enqueue(new Callback<List<dto.ActivityDto>>() {
                @Override
                public void onResponse(@NonNull Call<List<dto.ActivityDto>> call,
                                       @NonNull Response<List<dto.ActivityDto>> r) {
                    if (r.isSuccessful() && r.body() != null) merged.addAll(r.body());
                    else failed[0] = true;
                    if (--left[0] == 0) show(mine, merged, failed[0]);
                }

                @Override
                public void onFailure(@NonNull Call<List<dto.ActivityDto>> call, @NonNull Throwable t) {
                    failed[0] = true;
                    if (--left[0] == 0) show(mine, merged, true);
                }
            });
        }
    }

    private void show(int mine, @NonNull List<dto.ActivityDto> items, boolean failed) {
        if (mine != request || isFinishing()) return;
        refresh.setRefreshing(false);
        Skeleton.reveal(skeleton, null);
        // Newest first (ISO-8601 strings sort by time).
        Collections.sort(items, (a, b) -> String.valueOf(b.createdAt).compareTo(String.valueOf(a.createdAt)));
        list.setAdapter(new Adapter(items));
        if (!items.isEmpty()) {
            Motion.enterList(list);
            return;
        }
        state.setVisibility(View.VISIBLE);
        TextView title = findViewById(R.id.notif_state_title);
        TextView hint = findViewById(R.id.notif_state_hint);
        View action = findViewById(R.id.notif_state_action);
        if (failed) {
            state.setBackgroundResource(R.drawable.bg_error_plate);
            title.setText(R.string.notif_error_title);
            hint.setText(R.string.notif_error_hint);
            action.setVisibility(View.VISIBLE);
        } else {
            state.setBackground(null);
            title.setText(tab == GROUPS ? R.string.notif_empty_groups : R.string.notif_empty_title);
            hint.setText(tab == GROUPS ? R.string.notif_empty_groups_hint : R.string.notif_empty_hint);
            action.setVisibility(View.GONE);
        }
    }

    private static final class Adapter extends RecyclerView.Adapter<Adapter.Holder> {
        private final List<dto.ActivityDto> items;

        Adapter(List<dto.ActivityDto> items) { this.items = items; }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_notification, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            dto.ActivityDto a = items.get(position);
            String initial = a.initial != null && !a.initial.isEmpty() ? a.initial : "•";
            h.initial.setText(initial);
            h.text.setText(a.text);
            String when = RelativeTime.from(a.createdAt);
            String kind = h.kind(a.type);
            h.meta.setText(when == null || when.isEmpty() ? kind : kind + " · " + when);
        }

        @Override
        public int getItemCount() { return items.size(); }

        static final class Holder extends RecyclerView.ViewHolder {
            final TextView initial, text, meta;

            Holder(@NonNull View v) {
                super(v);
                initial = v.findViewById(R.id.notif_initial);
                text = v.findViewById(R.id.notif_text);
                meta = v.findViewById(R.id.notif_meta);
            }

            @NonNull
            String kind(@Nullable String type) {
                int res;
                if ("submission.created".equals(type)) res = R.string.notif_kind_log;
                else if ("system.reminder".equals(type)) res = R.string.notif_kind_reminder;
                else if ("week.locked".equals(type)) res = R.string.notif_kind_week;
                else return type == null ? "" : type.replace('.', ' ').toUpperCase(Locale.ROOT);
                return itemView.getContext().getString(res);
            }
        }
    }
}
