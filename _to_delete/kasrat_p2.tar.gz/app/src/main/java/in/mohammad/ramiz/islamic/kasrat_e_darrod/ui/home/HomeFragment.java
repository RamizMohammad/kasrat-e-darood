package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.MainActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.core.Haptics;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.LogService;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.RecitationStore;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.Totals;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.local.TokenStore;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.ApiClient;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.aladhan.AlAdhanClient;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.aladhan.AlAdhanDto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.AuraAvatarView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.CountRollTextView;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.components.StatTile;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.library.RecitationDetailActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.notifications.NotificationsActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Dates;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Motion;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Numbers;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.AppPrefs;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.LocationHelper;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.Skeleton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * P2 · Home (screen 8).
 *
 * Totals come from /dashboard and from {@link Totals}, which every log publishes,
 * so the tiles roll to new numbers wherever you logged. Prayer times come from
 * AlAdhan for the phone's location; today's copy is kept so the card shows at
 * once next time. Hijri and Gregorian dates are worked out on the phone.
 */
public class HomeFragment extends Fragment implements Totals.Listener {

    private static final int QUICK_MAX = 4;
    private static final String PRAYER_PREFS = "kasrat_prayer";

    private View root;
    private SwipeRefreshLayout refresh;
    private StatTile today, week, lifetime, streak;
    @Nullable private CountRollTextView globalTotal;
    @Nullable private TextView globalMeta;
    @Nullable private Integer myRank;
    private int pending;
    private String lang;

    private final ActivityResultLauncher<String[]> locationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                    result -> loadPrayers());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        root = view;
        lang = new AppPrefs(requireContext()).lang();
        refresh = view.findViewById(R.id.home_refresh);
        refresh.setColorSchemeColors(ContextCompat.getColor(requireContext(), R.color.amber));
        refresh.setProgressBackgroundColorSchemeColor(ContextCompat.getColor(requireContext(), R.color.surface_raised));
        refresh.setOnRefreshListener(this::loadAll);

        TokenStore store = new TokenStore(requireContext());
        String name = store.userName();
        ((TextView) view.findViewById(R.id.home_name)).setText(
                name != null && !name.isEmpty() ? name : getString(R.string.home_friend));
        AuraAvatarView avatar = view.findViewById(R.id.home_avatar);
        avatar.setAvatar(store.avatar() != null ? store.avatar() : store.photoUrl());
        avatar.setOnClickListener(v -> openTab(MainActivity.TAB_ME));
        view.findViewById(R.id.home_bell).setOnClickListener(v ->
                startActivity(new Intent(requireContext(), NotificationsActivity.class)));
        view.findViewById(R.id.home_totals_retry).setOnClickListener(v -> loadDashboard());

        today = view.findViewById(R.id.tile_today);
        week = view.findViewById(R.id.tile_week);
        lifetime = view.findViewById(R.id.tile_lifetime);
        streak = view.findViewById(R.id.tile_streak);

        bindDates();
        bindGlobalCard();

        // Start from what Home showed last time, then roll to anything newer.
        Totals.Snapshot shown = Totals.shown();
        if (shown != null) showTotals(shown, false);
        Totals.Snapshot latest = Totals.latest();
        if (latest != null && latest != shown) view.post(() -> showTotals(latest, true));

        bindCachedPrayers();
        loadAll();
        if (savedInstanceState == null) Motion.enterStack(view.findViewById(R.id.home_column));
    }

    @Override
    public void onStart() {
        super.onStart();
        Totals.addListener(this);
    }

    @Override
    public void onStop() {
        Totals.removeListener(this);
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        bindJumuah(cachedDhuhr());           // the countdown moves on while you're away
    }

    @Override
    public void onTotals(@NonNull Totals.Snapshot s) {
        if (root != null) showTotals(s, true);
    }

    private void loadAll() {
        pending = 3;
        loadDashboard();
        loadQuickLog();
        loadPrayers();
    }

    private void doneOne() {
        if (--pending <= 0 && refresh != null) refresh.setRefreshing(false);
    }

    // ── Totals ──────────────────────────────────────────────────────────────

    private void loadDashboard() {
        int version = Totals.version();
        ApiClient.get(requireContext()).dashboard(null).enqueue(new Callback<dto.DashboardResponse>() {
            @Override
            public void onResponse(@NonNull Call<dto.DashboardResponse> call,
                                   @NonNull Response<dto.DashboardResponse> r) {
                if (!isAdded()) return;
                doneOne();
                if (r.isSuccessful() && r.body() != null) {
                    totalsError(false);
                    // A log that finished while this was loading is newer: keep it.
                    if (Totals.version() == version) Totals.publish(r.body());
                } else {
                    totalsError(Totals.latest() == null);
                }
            }

            @Override
            public void onFailure(@NonNull Call<dto.DashboardResponse> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                doneOne();
                totalsError(Totals.latest() == null);
            }
        });
        ApiClient.get(requireContext()).leaderboard(null, "weekly").enqueue(new Callback<dto.LeaderboardResponse>() {
            @Override
            public void onResponse(@NonNull Call<dto.LeaderboardResponse> call,
                                   @NonNull Response<dto.LeaderboardResponse> r) {
                if (!isAdded() || !r.isSuccessful() || r.body() == null) return;
                myRank = r.body().me != null && r.body().me.rank > 0 ? r.body().me.rank : null;
                bindGlobalMeta();
            }

            @Override
            public void onFailure(@NonNull Call<dto.LeaderboardResponse> call, @NonNull Throwable t) { }
        });
    }

    private void totalsError(boolean show) {
        root.findViewById(R.id.home_totals_error).setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void showTotals(@NonNull Totals.Snapshot s, boolean animate) {
        today.setValue(s.today, animate && today.hasValue());
        week.setValue(s.week, animate && week.hasValue());
        lifetime.setValue(s.lifetime, animate && lifetime.hasValue());
        streak.setValue(s.streak, animate && streak.hasValue());
        if (globalTotal != null && s.groupWeek >= 0) {
            globalTotal.setCount(s.groupWeek, animate && globalTotal.hasCount());
        }
        Totals.markShown(s);
    }

    // ── Global circle card (your own groups arrive in P5) ──────────────────

    private void bindGlobalCard() {
        LinearLayout row = root.findViewById(R.id.home_groups_row);
        row.removeAllViews();
        View card = LayoutInflater.from(requireContext()).inflate(R.layout.item_group_card, row, false);
        ((TextView) card.findViewById(R.id.group_name)).setText(R.string.group_global_name);
        ((TextView) card.findViewById(R.id.group_privacy)).setText(R.string.group_public);
        globalTotal = card.findViewById(R.id.group_total);
        globalMeta = card.findViewById(R.id.group_meta);
        globalTotal.clearCount();
        bindGlobalMeta();
        card.setOnClickListener(v -> openTab(MainActivity.TAB_RANKS));
        row.addView(card);
    }

    private void bindGlobalMeta() {
        if (globalMeta == null) return;
        globalMeta.setText(myRank != null
                ? getString(R.string.group_meta_week_rank, myRank)
                : getString(R.string.group_meta_week));
    }

    // ── Quick log: your four most-logged recitations ────────────────────────

    private void loadQuickLog() {
        ApiClient.get(requireContext()).recentSubmissions(100).enqueue(new Callback<List<dto.MySubmissionDto>>() {
            @Override
            public void onResponse(@NonNull Call<List<dto.MySubmissionDto>> call,
                                   @NonNull Response<List<dto.MySubmissionDto>> r) {
                if (!isAdded()) return;
                doneOne();
                if (!r.isSuccessful() || r.body() == null) return;
                List<String> top = mostLogged(r.body());
                RecitationStore.get(requireContext()).load(new RecitationStore.Callback() {
                    @Override public void onList(@NonNull List<dto.RecitationDto> list, boolean fromCache) {
                        if (isAdded()) bindQuickLog(top);
                    }

                    @Override public void onError(boolean offline) { }
                });
            }

            @Override
            public void onFailure(@NonNull Call<List<dto.MySubmissionDto>> call, @NonNull Throwable t) {
                if (isAdded()) doneOne();
            }
        });
    }

    @NonNull
    private static List<String> mostLogged(@NonNull List<dto.MySubmissionDto> subs) {
        Map<String, Integer> times = new HashMap<>();
        Map<String, Integer> firstSeen = new HashMap<>();
        for (int i = 0; i < subs.size(); i++) {
            String id = subs.get(i).recitationId;
            if (id == null) continue;
            times.merge(id, 1, Integer::sum);
            firstSeen.putIfAbsent(id, i);
        }
        List<String> ids = new ArrayList<>(times.keySet());
        // Most logged first; ties go to the one logged most recently.
        Collections.sort(ids, (a, b) -> {
            int c = Integer.compare(times.get(b), times.get(a));
            return c != 0 ? c : Integer.compare(firstSeen.get(a), firstSeen.get(b));
        });
        return ids.size() > QUICK_MAX ? ids.subList(0, QUICK_MAX) : ids;
    }

    private void bindQuickLog(@NonNull List<String> ids) {
        LinearLayout row = root.findViewById(R.id.home_quick_row);
        row.removeAllViews();
        RecitationStore store = RecitationStore.get(requireContext());
        for (String id : ids) {
            dto.RecitationDto r = store.byId(id);
            if (r == null) continue;
            View chip = LayoutInflater.from(requireContext()).inflate(R.layout.item_quick_log, row, false);
            ((TextView) chip.findViewById(R.id.quick_arabic)).setText(r.arabicName);
            String title = RecitationStore.title(r, lang);
            ((TextView) chip.findViewById(R.id.quick_name)).setText(title);
            int step = RecitationStore.step(r);
            ((TextView) chip.findViewById(R.id.quick_step)).setText("+" + Numbers.format(step));
            chip.setContentDescription(getString(R.string.quick_log_cd, step, title));
            chip.setOnClickListener(v -> quickLog(r, UUID.randomUUID().toString()));
            chip.setOnLongClickListener(v -> {
                startActivity(RecitationDetailActivity.intent(requireContext(), r.id));
                return true;
            });
            row.addView(chip);
        }
        boolean empty = row.getChildCount() == 0;
        root.findViewById(R.id.home_quick_scroll).setVisibility(empty ? View.GONE : View.VISIBLE);
        root.findViewById(R.id.home_quick_empty).setVisibility(empty ? View.VISIBLE : View.GONE);
    }

    /** Logs one step; {@code uuid} stays the same on retry so it can't count twice. */
    private void quickLog(@NonNull dto.RecitationDto r, @NonNull String uuid) {
        Context ctx = requireContext();
        Haptics.tick(ctx);
        int step = RecitationStore.step(r);
        String title = RecitationStore.title(r, lang);
        LogService.logOne(ctx, r.id, step, uuid, new LogService.Result() {
            @Override
            public void onLogged(@NonNull dto.Totals totals) {
                if (!isAdded()) return;
                Haptics.click(requireContext());
                snack(getString(R.string.quick_logged, Numbers.format(step), title), null, null);
            }

            @Override
            public void onFailed(@NonNull String message, boolean offline) {
                if (!isAdded()) return;
                Haptics.reject(requireContext());
                snack(message, getString(R.string.action_retry), () -> quickLog(r, uuid));
            }
        });
    }

    private void snack(@NonNull String text, @Nullable String action, @Nullable Runnable onAction) {
        Snackbar s = Snackbar.make(root, text, Snackbar.LENGTH_LONG);
        View bar = requireActivity().findViewById(R.id.bottom_bar);
        if (bar != null) s.setAnchorView(bar);
        if (action != null && onAction != null) s.setAction(action, v -> onAction.run());
        s.show();
    }

    // ── Dates ───────────────────────────────────────────────────────────────

    private void bindDates() {
        Date now = new Date();
        ((TextView) root.findViewById(R.id.home_hijri)).setText(Dates.hijri(now));
        ((TextView) root.findViewById(R.id.home_gregorian)).setText(Dates.gregorian(now));
        TextView ramadan = root.findViewById(R.id.home_ramadan);
        if (Dates.hijriMonth(now) == 9) {
            ramadan.setVisibility(View.VISIBLE);
            ramadan.setText(getString(R.string.home_ramadan_day, Dates.hijriDay(now)));
        } else {
            ramadan.setVisibility(View.GONE);
        }
    }

    // ── Prayer times ────────────────────────────────────────────────────────

    private static final int[] PRAYER_NAMES = {
            R.string.prayer_fajr, R.string.prayer_dhuhr, R.string.prayer_asr,
            R.string.prayer_maghrib, R.string.prayer_isha};

    private SharedPreferences prayerPrefs() {
        return requireContext().getSharedPreferences(PRAYER_PREFS, Context.MODE_PRIVATE);
    }

    private static String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** Today's saved times, if any, so the card appears at once. */
    private void bindCachedPrayers() {
        SharedPreferences p = prayerPrefs();
        String times = p.getString("times", null);
        if (todayKey().equals(p.getString("day", null)) && times != null) {
            showPrayers(times.split(","), p.getString("zone", null));
        } else {
            Skeleton.shimmer(root.findViewById(R.id.prayer_skeleton));
        }
        bindJumuah(cachedDhuhr());
    }

    @Nullable
    private String cachedDhuhr() {
        if (!isAdded()) return null;
        SharedPreferences p = prayerPrefs();
        String times = p.getString("times", null);
        if (times == null) return null;
        String[] t = times.split(",");
        return t.length == 5 ? t[1] : null;
    }

    private void loadPrayers() {
        if (!isAdded()) return;
        if (!LocationHelper.hasPermission(requireContext())) {
            doneOne();
            if (!hasPrayersToday()) {
                prayerState(R.string.prayer_need_location_title, R.string.prayer_need_location_body,
                        R.string.prayer_allow_location, v -> askLocation());
            }
            return;
        }
        LocationHelper.current(requireContext(), latLon -> {
            if (!isAdded()) return;
            if (latLon == null) {
                doneOne();
                if (!hasPrayersToday()) {
                    prayerState(R.string.prayer_no_fix_title, R.string.prayer_no_fix_body,
                            R.string.action_try_again, v -> {
                                pending = 1;
                                loadPrayers();
                            });
                }
                return;
            }
            fetchPrayers(latLon);
        });
    }

    private boolean hasPrayersToday() {
        return todayKey().equals(prayerPrefs().getString("day", null));
    }

    private void askLocation() {
        boolean canAsk = shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_FINE_LOCATION)
                || !prayerPrefs().getBoolean("asked", false);
        if (canAsk) {
            prayerPrefs().edit().putBoolean("asked", true).apply();
            locationPermission.launch(new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION});
        } else {
            // "Don't ask again" was chosen: only Settings can turn it on now.
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", requireContext().getPackageName(), null)));
        }
    }

    private void fetchPrayers(@NonNull double[] latLon) {
        String date = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
        AlAdhanClient.get().timings(date, latLon[0], latLon[1],
                AlAdhanClient.DEFAULT_METHOD, AlAdhanClient.DEFAULT_SCHOOL)
                .enqueue(new Callback<AlAdhanDto.Response>() {
                    @Override
                    public void onResponse(@NonNull Call<AlAdhanDto.Response> call,
                                           @NonNull Response<AlAdhanDto.Response> r) {
                        if (!isAdded()) return;
                        doneOne();
                        AlAdhanDto.Data d = r.isSuccessful() && r.body() != null ? r.body().data : null;
                        if (d == null || d.timings == null) {
                            prayersFailed();
                            return;
                        }
                        AlAdhanDto.Timings t = d.timings;
                        String[] times = {clean(t.fajr), clean(t.dhuhr), clean(t.asr), clean(t.maghrib), clean(t.isha)};
                        String zone = d.meta != null ? d.meta.timezone : null;
                        prayerPrefs().edit()
                                .putString("day", todayKey())
                                .putString("times", String.join(",", times))
                                .putString("zone", zone)
                                .apply();
                        showPrayers(times, zone);
                        bindJumuah(times[1]);
                    }

                    @Override
                    public void onFailure(@NonNull Call<AlAdhanDto.Response> call, @NonNull Throwable t) {
                        if (!isAdded()) return;
                        doneOne();
                        prayersFailed();
                    }
                });
    }

    private void prayersFailed() {
        if (hasPrayersToday()) return;                     // keep today's saved times
        prayerState(R.string.prayer_failed_title, R.string.prayer_failed_body,
                R.string.action_try_again, v -> {
                    pending = 1;
                    loadPrayers();
                });
    }

    private void prayerState(int title, int body, int action, View.OnClickListener onAction) {
        Skeleton.reveal(root.findViewById(R.id.prayer_skeleton), null);
        root.findViewById(R.id.prayer_card).setVisibility(View.GONE);
        root.findViewById(R.id.prayer_state).setVisibility(View.VISIBLE);
        ((TextView) root.findViewById(R.id.prayer_state_title)).setText(title);
        ((TextView) root.findViewById(R.id.prayer_state_body)).setText(body);
        MaterialButton btn = root.findViewById(R.id.prayer_state_action);
        btn.setText(action);
        btn.setOnClickListener(onAction);
    }

    private void showPrayers(@NonNull String[] times, @Nullable String zone) {
        if (times.length != 5) return;
        root.findViewById(R.id.prayer_state).setVisibility(View.GONE);
        Skeleton.reveal(root.findViewById(R.id.prayer_skeleton), root.findViewById(R.id.prayer_card));

        Calendar now = Calendar.getInstance();
        int nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int next = -1;
        for (int i = 0; i < 5; i++) {
            int m = minutes(times[i]);
            if (m >= 0 && m > nowMin) {
                next = i;
                break;
            }
        }
        boolean tomorrow = next < 0;          // after Isha: next is tomorrow's Fajr
        int nextIdx = tomorrow ? 0 : next;

        LinearLayout rows = root.findViewById(R.id.prayer_rows);
        rows.removeAllViews();
        for (int i = 0; i < 5; i++) {
            View row = LayoutInflater.from(requireContext()).inflate(R.layout.item_prayer, rows, false);
            ((TextView) row.findViewById(R.id.prayer_name)).setText(PRAYER_NAMES[i]);
            ((TextView) row.findViewById(R.id.prayer_time)).setText(times[i]);
            if (i == nextIdx) row.setBackgroundResource(R.drawable.bg_prayer_next);
            rows.addView(row);
        }

        String nextName = getString(PRAYER_NAMES[nextIdx]);
        ((TextView) root.findViewById(R.id.prayer_next)).setText(
                getString(R.string.prayer_next_label, nextName, times[nextIdx]));
        int target = minutes(times[nextIdx]) + (tomorrow ? 24 * 60 : 0);
        int left = Math.max(0, target - nowMin);
        ((TextView) root.findViewById(R.id.prayer_next_in)).setText(left >= 60
                ? getString(R.string.prayer_in_hm, left / 60, left % 60)
                : getString(R.string.prayer_in_m, left));
        TextView place = root.findViewById(R.id.prayer_place);
        place.setVisibility(zone != null ? View.VISIBLE : View.GONE);
        if (zone != null) place.setText(zone.replace('_', ' '));
    }

    /** "HH:mm" → minutes after midnight, or -1. */
    private static int minutes(@Nullable String hhmm) {
        if (hhmm == null) return -1;
        String[] p = hhmm.split(":");
        if (p.length < 2) return -1;
        try {
            return Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** "06:03 (IST)" → "06:03". */
    @NonNull
    private static String clean(@Nullable String time) {
        if (time == null) return "--:--";
        int space = time.indexOf(' ');
        return space > 0 ? time.substring(0, space) : time;
    }

    // ── Jumu'ah ─────────────────────────────────────────────────────────────

    /** Countdown to Friday's Dhuhr (today's Dhuhr time, or 13:00 until times load). */
    private void bindJumuah(@Nullable String dhuhr) {
        if (root == null || !isAdded()) return;
        int at = minutes(dhuhr);
        if (at < 0) at = 13 * 60;
        Calendar now = Calendar.getInstance();
        Calendar fri = (Calendar) now.clone();
        int delta = (Calendar.FRIDAY - now.get(Calendar.DAY_OF_WEEK) + 7) % 7;
        fri.add(Calendar.DAY_OF_MONTH, delta);
        fri.set(Calendar.HOUR_OF_DAY, at / 60);
        fri.set(Calendar.MINUTE, at % 60);
        fri.set(Calendar.SECOND, 0);
        fri.set(Calendar.MILLISECOND, 0);
        if (fri.before(now)) fri.add(Calendar.DAY_OF_MONTH, 7);   // this Friday's has passed

        long mins = (fri.getTimeInMillis() - now.getTimeInMillis()) / 60_000L;
        int days = (int) (mins / (24 * 60));
        int hours = (int) ((mins / 60) % 24);
        String text;
        if (days == 0 && now.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
            text = getString(R.string.jumuah_today);
        } else if (days == 0) {
            text = getResources().getQuantityString(R.plurals.jumuah_hours, Math.max(1, hours), Math.max(1, hours));
        } else {
            text = getString(R.string.jumuah_in,
                    getResources().getQuantityString(R.plurals.jumuah_days, days, days),
                    getResources().getQuantityString(R.plurals.jumuah_hours, hours, hours));
        }
        ((TextView) root.findViewById(R.id.jumuah_countdown)).setText(text);
        ((TextView) root.findViewById(R.id.jumuah_time)).setText(
                String.format(Locale.US, "%02d:%02d", at / 60, at % 60));
    }

    private void openTab(int tab) {
        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).openTab(tab);
    }
}
