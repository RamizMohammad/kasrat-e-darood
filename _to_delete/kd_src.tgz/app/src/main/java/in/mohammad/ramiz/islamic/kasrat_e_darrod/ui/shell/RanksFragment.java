package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.shell;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButtonToggleGroup;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.stats.LeaderboardFragment;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.stats.StatsFragment;

/**
 * Ranks tab until P4: Board (v2 leaderboard) and Stats (v2 weekly stats,
 * which also holds the admins' close-week button).
 */
public class RanksFragment extends Fragment {

    public RanksFragment() {
        super(R.layout.fragment_ranks);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        MaterialButtonToggleGroup toggle = view.findViewById(R.id.ranks_toggle);
        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            getChildFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.tab_in, R.anim.tab_out)
                    .replace(R.id.ranks_host, checkedId == R.id.ranks_stats
                            ? new StatsFragment() : new LeaderboardFragment())
                    .commit();
        });
        if (savedInstanceState == null) {
            getChildFragmentManager().beginTransaction()
                    .replace(R.id.ranks_host, new LeaderboardFragment())
                    .commit();
        }
    }
}
