package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.auth;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.base.Router;

/**
 * Launcher. The Android 12+ SplashScreen API draws the crescent animation
 * (Theme.Kasrat.Starting); this activity only decides where to go next.
 */
@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);
        startActivity(Router.start(this));
        finish();
    }
}
