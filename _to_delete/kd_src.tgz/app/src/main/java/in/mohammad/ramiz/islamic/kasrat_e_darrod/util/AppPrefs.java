package in.mohammad.ramiz.islamic.kasrat_e_darrod.util;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;

/** App-wide UI settings: language + dark mode, persisted in SharedPreferences. */
public final class AppPrefs {
    private static final String PREFS = "noor_settings";
    private static final String KEY_LANG = "lang";
    private static final String KEY_NIGHT = "night_mode";
    private static final String KEY_LANG_CHOSEN = "lang_chosen";
    private static final String KEY_ONBOARDED = "onboarding_done";

    private final SharedPreferences prefs;

    public AppPrefs(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // --- Language (en | hi | ur) ---
    public String lang() { return prefs.getString(KEY_LANG, "en"); }

    public void setLang(String tag) {
        prefs.edit().putString(KEY_LANG, tag).apply();
        applyLanguage(tag);
    }

    /** Apply a language tag as the app's per-app locale (persisted by AppCompat). */
    public static void applyLanguage(String tag) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag));
    }

    // --- First run ---
    /** True once the user picked a language on the first-run screen (or upgraded from v2). */
    public boolean languageChosen() { return prefs.getBoolean(KEY_LANG_CHOSEN, false); }
    public void markLanguageChosen() { prefs.edit().putBoolean(KEY_LANG_CHOSEN, true).apply(); }

    /** True once onboarding was finished or skipped on this device. */
    public boolean onboardingDone() { return prefs.getBoolean(KEY_ONBOARDED, false); }
    public void markOnboardingDone() { prefs.edit().putBoolean(KEY_ONBOARDED, true).apply(); }

    // --- Dark mode (legacy v2 setting; v3 is dark-only) ---
    public boolean darkMode() { return prefs.getBoolean(KEY_NIGHT, false); }

    public void setDarkMode(boolean on) {
        prefs.edit().putBoolean(KEY_NIGHT, on).apply();
        applyDarkMode(on);
    }

    public static void applyDarkMode(boolean on) {
        // v3 is dark-only; the old toggle no longer switches to light.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }
}
