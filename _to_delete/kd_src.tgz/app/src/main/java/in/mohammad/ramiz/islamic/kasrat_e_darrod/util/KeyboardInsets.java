package in.mohammad.ramiz.islamic.kasrat_e_darrod.util;

import android.app.Activity;
import android.view.View;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Keeps form fields visible above the soft keyboard.
 *
 * With targetSdk 35+ the system enforces edge-to-edge, so
 * {@code windowSoftInputMode="adjustResize"} alone no longer shrinks the
 * content — the IME inset must be applied manually. This pads the activity's
 * content view by the keyboard height (the padded strip sits behind the
 * keyboard, so it is never visible), letting ScrollViews scroll the focused
 * field into view.
 */
public final class KeyboardInsets {

    private KeyboardInsets() { }

    /** Call after {@code setContentView()} in any activity containing forms. */
    public static void attach(Activity activity) {
        View content = activity.findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(content, (v, insets) -> {
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(),
                    v.getPaddingRight(), ime.bottom);
            return insets;
        });
    }
}
