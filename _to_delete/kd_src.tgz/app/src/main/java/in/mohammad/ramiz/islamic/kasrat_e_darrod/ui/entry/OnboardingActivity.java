package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.entry;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.core.Haptics;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.local.TokenStore;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.ApiClient;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.data.remote.dto;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.databinding.ActivityOnboardingBinding;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.avatar.AvatarStudioActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.base.BaseActivity;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.nav.Nav;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.EdgeInsets;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.util.Motion;
import in.mohammad.ramiz.islamic.kasrat_e_darrod.util.AppPrefs;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * P1 · Onboarding, shown once per device after sign-in: three slides
 * (log · circles · ranks), then the avatar studio. Skip goes straight home;
 * the avatar can be made later from Me.
 */
public class OnboardingActivity extends BaseActivity {

    private static final String STATE_SLIDE = "slide";

    private static final int[] TAGS = {R.string.onb_1_tag, R.string.onb_2_tag, R.string.onb_3_tag};
    private static final int[] TITLES = {R.string.onb_1_title, R.string.onb_2_title, R.string.onb_3_title};
    private static final int[] BODIES = {R.string.onb_1_body, R.string.onb_2_body, R.string.onb_3_body};
    private static final int[] ICONS = {R.drawable.ic_book_open, R.drawable.ic_groups, R.drawable.ic_trophy};

    private ActivityOnboardingBinding b;
    private View[] dots;
    private int slide;
    private boolean saving;

    private final ActivityResultLauncher<Intent> avatarStudio = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                String spec = result.getData() == null ? null
                        : result.getData().getStringExtra(AvatarStudioActivity.EXTRA_SPEC);
                if (result.getResultCode() == RESULT_OK && spec != null) saveAvatar(spec);
                else finishOnboarding();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        b = ActivityOnboardingBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        EdgeInsets.padSystemBars(b.root, false);
        dots = new View[]{b.dot0, b.dot1, b.dot2};
        slide = savedInstanceState != null ? savedInstanceState.getInt(STATE_SLIDE, 0) : 0;

        b.btnSkip.setOnClickListener(v -> finishOnboarding());
        b.btnNext.setOnClickListener(v -> {
            if (saving) return;
            Haptics.tick(this);
            if (slide < TITLES.length - 1) {
                show(slide + 1, true);
            } else {
                avatarStudio.launch(AvatarStudioActivity.intent(this, new TokenStore(this).avatar(), false));
            }
        });
        show(slide, false);
    }

    private void show(int index, boolean animate) {
        slide = index;
        bind(TAGS[index], TITLES[index], BODIES[index], ICONS[index]);
        for (int i = 0; i < dots.length; i++) {
            boolean on = i == index;
            dots[i].setBackgroundResource(on ? R.drawable.dot_amber : R.drawable.dot_muted);
            dots[i].getLayoutParams().width = (int) (getResources().getDisplayMetrics().density * (on ? 18 : 6));
            dots[i].requestLayout();
        }
        boolean last = index == TITLES.length - 1;
        b.btnNext.setText(last ? R.string.onb_start : R.string.onb_next);
        if (animate && Motion.enabled()) {
            b.copy.setAlpha(0f);
            b.copy.setTranslationY(12 * getResources().getDisplayMetrics().density);
            b.copy.animate().alpha(1f).translationY(0f).setDuration(260).start();
            b.art.setRotation(index % 2 == 0 ? -4f : 4f);
            b.art.setScaleX(0.94f);
            b.art.setScaleY(0.94f);
            b.art.animate().scaleX(1f).scaleY(1f).setDuration(300).start();
        }
    }

    private void bind(@StringRes int tag, @StringRes int title, @StringRes int body, @DrawableRes int icon) {
        b.slideTag.setText(tag);
        b.slideTitle.setText(title);
        b.slideBody.setText(body);
        b.artIcon.setImageResource(icon);
    }

    private void saveAvatar(@NonNull String spec) {
        saving = true;
        b.btnNext.setEnabled(false);
        b.btnSkip.setEnabled(false);
        b.btnNext.setText(R.string.onb_saving);
        ApiClient.get(this).updateMe(dto.UserUpdateRequest.avatar(spec)).enqueue(new Callback<dto.UserDto>() {
            @Override
            public void onResponse(@NonNull Call<dto.UserDto> call, @NonNull Response<dto.UserDto> response) {
                if (response.isSuccessful()) {
                    new TokenStore(OnboardingActivity.this).setAvatar(spec);
                } else {
                    Toast.makeText(OnboardingActivity.this, R.string.onb_avatar_failed, Toast.LENGTH_LONG).show();
                }
                finishOnboarding();
            }

            @Override
            public void onFailure(@NonNull Call<dto.UserDto> call, @NonNull Throwable t) {
                Toast.makeText(OnboardingActivity.this, R.string.onb_avatar_failed, Toast.LENGTH_LONG).show();
                finishOnboarding();
            }
        });
    }

    private void finishOnboarding() {
        new AppPrefs(this).markOnboardingDone();
        Nav.next(this);
        finish();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt(STATE_SLIDE, slide);
    }
}
