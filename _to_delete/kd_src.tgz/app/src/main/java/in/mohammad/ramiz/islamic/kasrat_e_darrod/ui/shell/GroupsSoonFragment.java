package in.mohammad.ramiz.islamic.kasrat_e_darrod.ui.shell;

import androidx.fragment.app.Fragment;

import in.mohammad.ramiz.islamic.kasrat_e_darrod.R;

/** Groups tab until P5 builds circles. */
public class GroupsSoonFragment extends Fragment {
    public GroupsSoonFragment() {
        super(R.layout.fragment_groups_soon);
    }
}
